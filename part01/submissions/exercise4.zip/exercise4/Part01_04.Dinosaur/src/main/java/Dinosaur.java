
public class Dinosaur {

    public static void main(String[] args) {
        System.out.println("Once upon a time");
        System.out.println("there was");
        System.out.println("a dinosaur");
    }
}
